package org.taghessen.agit;

import java.util.ArrayList;

import org.taghessen.agit.models.Activity;

public class App {

	public static void main(String[] args) {
		RequestHandler rq = new RequestHandler();

		String str = rq.send();
		Stats st = new Stats();
		ArrayList<Activity> act= st.parse(str);
		
		System.out.println("Stats : ");
		System.out.println("------------------");
		System.out.println("Number of activities : " + act.size());
	}

}
