package org.taghessen.agit;

import java.util.ArrayList;

import org.taghessen.agit.models.Activity;

public class Stats {

	public ArrayList<Activity> parse(String s) { 
		ArrayList<Activity> activities= new ArrayList<Activity>() ;
		String[] lignes ;
		lignes= s.split("\n");	
		for(String ligne:lignes) {
			Activity a = new Activity();
			String[] str= ligne.split(";");
			a.name=str[0];
			a.date=str[1];
			if(str.length==3) {
				a.url=str[2];
			}
			activities.add(a);
		}
		return activities ;
	}


}
