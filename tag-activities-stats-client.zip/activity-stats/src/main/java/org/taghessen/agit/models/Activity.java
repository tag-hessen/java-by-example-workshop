package org.taghessen.agit.models;

public class Activity {
	public String name ;
	public String date ;
	public String url ;
}
