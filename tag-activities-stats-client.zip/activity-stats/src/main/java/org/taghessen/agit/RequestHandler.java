package org.taghessen.agit;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class RequestHandler {
	
	public String send() {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet("http://tag-hessen.org/keeptrack/activities.txt");
		
		CloseableHttpResponse response1 ;
		
		try {
			response1 = httpclient.execute(httpGet);
			
			System.out.println(response1.getStatusLine());
		    
			HttpEntity entity1 = response1.getEntity();
		    
		    String s = EntityUtils.toString(entity1) ;
		    
		    //System.out.println(s) ;
		    EntityUtils.consume(entity1);
		    
		    return s ;
		    
		    
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return null ;

		
	}
	
}
