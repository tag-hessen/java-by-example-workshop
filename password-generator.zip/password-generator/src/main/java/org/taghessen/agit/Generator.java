package org.taghessen.agit;

import java.util.Random;

public class Generator {
	public String generate(int numberOfChars) {
		StringBuilder password = new StringBuilder() ;
		
		for(int i = 0 ; i < numberOfChars; i++) {
			Random r = new Random();
			char c = (char)(r.nextInt(26) + 'a');
			
			password.append(c);
		}
		
		return password.toString() ;
	}
}
