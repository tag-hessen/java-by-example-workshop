package org.taghessen.agit;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

// Our library imports
import static org.kohsuke.args4j.ExampleMode.ALL;
import org.kohsuke.args4j.*;

public class App {
	
	@Option(name="-id",usage="ID of the generated password")
	private String identifier = "id"; // default value
	
	@Option(name="-number",usage="Number of characters to be generated in the password")
	private int numberOfChars = 6 ; // default value
	
	@Option(name="-output",usage="Save to this file")
	private File output = new File("./output.txt");
	
	
	public static void main(String[] args) {
		new App().run(args) ;
	}
	
	@SuppressWarnings("deprecation")
	public void run(String[] args) {
		CmdLineParser parser = new CmdLineParser(this);
		
		try {
            // parse the arguments.
            parser.parseArgument(args);
        } catch( CmdLineException e ) {
            
        	System.err.println(e.getMessage());
            System.err.println("Usage: java GeneratePassword [options...]");
            // print the list of available options
            parser.printUsage(System.err);
            System.err.println();

            // print option sample. This is useful some time
            System.err.println("  Example: java GeneratePassword"+parser.printExample(ALL));

            return;
        }
		
		// generate password
		Generator g = new Generator() ;
		String password = g.generate(numberOfChars) ;
		
		// save the password to the output file, we use append
		if(!output.exists()) { // if file does not exist, we create it
			try {
				output.createNewFile() ;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			String line = identifier + ";" + password + "\n" ;
			Files.write(output.toPath(), line.getBytes() , StandardOpenOption.APPEND);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Password generated !");
	}

}
