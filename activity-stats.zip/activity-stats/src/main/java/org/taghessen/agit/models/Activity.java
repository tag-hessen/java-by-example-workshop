package org.taghessen.agit.models;

public class Activity {
	public Date b ;
}
